return {mode=49154,stage=49155,lives=49156,inv=49157,px=49158,py=49159,orbs=49162,norb=49170,shield=49171,beam=49172,bossx=49184,bossactive=49187,score=49191,shots=49257,bullets=49341,object_size=6}
