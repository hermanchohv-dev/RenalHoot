local m=manager.machine
local mem=m.devices[":maincpu"].spaces["program"]
local frame=0
local function input(name,value)
 for _,p in pairs(m.ioport.ports) do for _,f in pairs(p.fields) do if f.name==name then f:set_value(value) end end end
end
local log=io.open('/workspace/verdant-mame/analysis/runtime.tsv','w')
emu.register_frame_done(function()
 frame=frame+1
 if frame==120 then input('1 Player Start',1) end
 if frame==125 then input('1 Player Start',0);input('P1 Button 1',1) end
 if frame==200 then input('P1 Left',1) end
 if frame==220 then input('P1 Left',0) end
 if frame==240 then input('P1 Button 2',1) end
 if frame==245 then input('P1 Button 2',0) end
 if frame==60 or frame==400 or frame==1000 or frame==1800 then m.screens[":screen"]:snapshot(string.format('/workspace/verdant-mame/analysis/native-%04d.png',frame)) end
 if frame%30==0 then log:write(string.format('%d\t%d\t%d\t%d\t%d\t%d\n',frame,mem:read_u8(0xc002),mem:read_u8(0xc004),mem:read_u8(0xc006),mem:read_u8(0xc012),mem:read_u16(0xc027)));log:flush() end
 if frame>=2000 then log:close();m:exit() end
end,'frame')
