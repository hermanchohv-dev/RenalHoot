# Entradas de la construcción

`geminib-original.zip` es el archivo aportado por el usuario. SHA-256:
`2f509986b7da9738025e30231fd26c50ceceea762b6ae0223a3804d8ea002da5`.

El empaquetador verifica ese hash antes de reutilizar las ROM de sonido, banco
y la imagen alternativa no cargada. Programa, texto y gráficos de la adaptación
se generan desde las fuentes del proyecto.

`rom-layout.json` define la correspondencia de archivos y el CRC del catálogo
original. No contiene CRC falsificados para que un cargador acepte el nuevo juego.
Los CRC y SHA reales de la salida se generan en `build/rom-manifest.json`.
