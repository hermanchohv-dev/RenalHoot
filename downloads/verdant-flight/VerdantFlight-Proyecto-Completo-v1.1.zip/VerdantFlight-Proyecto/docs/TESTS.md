# Pruebas realizadas y límites

## Edición actual

`evidence/current/results.json` identifica el binario por SHA-256 y registra emulador, anfitrión, comandos, resultados y audio. Las pruebas se ejecutaron en **MAME 0.276, Linux x86-64** con el perfil `dist/mame0276/geminib.zip`.

### Entradas y partida normal

`tests/inputs.lua` inicia la partida y pulsa los campos de entrada de MAME. **No escribe RAM del juego.** Comprueba inicio, proyectiles activos, izquierda, derecha, arriba, abajo y consumo de un orbe. Después mantiene el disparo y observa daño, pérdida de vidas y game over. Registra posiciones y estados en `runtime.tsv` y genera capturas.

El resultado fue PASS, incluido arriba/disminución de Y y abajo/aumento de Y. La ejecución produjo 51,3 segundos de audio estéreo a 48 kHz con señal no nula. Esto cubre una partida automatizada que termina por daño, no una campaña superada manualmente.

### Progresión controlada

`tests/progression.lua` establece invulnerabilidad en RAM durante la prueba y coloca tipos de orbe en el inventario. Valida el consumo de abanico y nova y la activación de los temporizadores de escudo y disparo reforzado. Cuando aparece un jefe, alinea la nave mediante entradas normales y lo daña con el disparo del juego; no escribe directamente su vida ni su muerte.

Se observaron las tres fases, los tres jefes y la victoria. El resultado fue PASS. El audio capturado dura 160,54 segundos, estéreo a 48 kHz. **La invulnerabilidad y el inventario forzado sólo pertenecen al script de prueba externo**, no a la ROM distribuida. Estas aserciones no demuestran que cada habilidad tenga buen balance ni validan visualmente todos sus detalles.

### Audio y capturas

Los archivos `audio.flac` conservan sin pérdidas el audio completo de ambas ejecuciones. El runner decodificó cada FLAC y comprobó que el SHA-256 del PCM coincide con el WAV original antes de eliminar el WAV generado. Las capturas PNG de título, partida, jefes, game over y victoria provienen de MAME. Son capturas reales, no ilustraciones.

La música y los efectos proceden de las ROM originales de sonido; comprobar señal PCM no es un análisis musical de fidelidad a una placa real. No se presenta una nueva composición como si fuera el tema del arcade.

### Construcción, empaquetado y definición nueva

`tools/verify_project.py` comprueba la integridad de los ZIP, nombres, tamaños, igualdad de datos entre perfiles, hash de la entrada, permanencia de ROM de sonido y coherencia de los hashes del controlador nuevo. Se construyó desde las fuentes en esta entrega y se comprobó repetibilidad.

El parche de MAME para el identificador `verdantflight` sólo se aplicó **en seco** a las fuentes de referencia; no se compiló ni se arrancó ese controlador. La ejecución realizada utiliza el controlador existente `geminib`, con advertencias de checksum esperadas. Ninguna prueba de auditoría se ha descrito como pasada para el catálogo histórico: la ROM modificada no coincide con ese catálogo.

## Qué no está probado

- Ejecución del candidato en el Game Stick M15 físico.
- Que el M15 arranque `maincode_64` en vez de `maincode_128`.
- Número exacto de versión del núcleo arcade integrado y tolerancia a CRC modificados.
- Incorporación de un juego nuevo a su índice o menú.
- Controlador `verdantflight` compilado, ni su instalación en el firmware del M15.
- Otras versiones de MAME, FBA/FBNeo, otros sistemas anfitriones o una placa Tecmo real.
- Una partida manual completa, rendimiento en el M15, dos jugadores o persistencia de récord.

## Evidencia histórica

`evidence/historical/` conserva las pruebas anteriores y el binario HEX del programa histórico. El registro de progresión final corresponde a la versión cuyo ZIP tenía SHA-256 `eb0e8e95ab01fbb1e3f071155423283efddb22dc62559dac10f6a5b661f5dcc4` y cuya fuente se adjunta en `src/` de esa carpeta. La prueba natural más antigua se hizo antes de los últimos ajustes de menú y contacto con el jefe; se conserva como registro informativo, no como validación del binario actual.

Las pruebas históricas no pulsaban arriba/abajo. Durante esta auditoría se detectó esa inversión y se corrigió en la edición actual; la nueva batería sí cubre las cuatro direcciones. Los paths absolutos en los registros antiguos describen el entorno original y no son requisitos de instalación.

## Repetir

```sh
python3 tools/build.py
python3 tools/verify_project.py
python3 tools/run_tests.py --mame /ruta/a/mame --output evidence/retest
```

El runner usa `-video none`, audio SDL con backend dummy y scripts Lua. FFmpeg es opcional para comprimir audio sin pérdidas; sin él se conserva el WAV. Un código de salida cero de MAME no basta: el runner exige los marcadores PASS y señal PCM. Los resultados nuevos no sobrescriben la evidencia suministrada si se utiliza otra ruta de salida.

La ROM histórica se conserva también en `dist/historical/geminib.zip`, para distinguir su identidad de la edición corregida. Las capturas JPG actuales se han ampliado 4× sin filtrado; los PNG guardan la resolución nativa.
