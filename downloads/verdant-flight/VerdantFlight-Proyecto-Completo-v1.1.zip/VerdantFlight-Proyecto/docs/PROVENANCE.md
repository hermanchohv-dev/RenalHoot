# Procedencia y dependencias

`src/game.c` y `src/crt0.s` implementan la adaptación nativa. `tools/build_assets.py` genera el arte en píxeles y las paletas; no extrae los sprites del juego comercial. `src/palette.h` es una salida generada que se conserva para inspección.

`inputs/geminib-original.zip` es el archivo ROM que aportó el usuario. Se incluye como entrada de reconstrucción, con su hash validado. El proyecto reutiliza su CPU de sonido, sus muestras, su banco y una imagen alternativa no cargada. Esas ROM y su música siguen siendo material del juego original; no se presentan como código fuente o composiciones creadas en este proyecto. El paquete no representa una liberación de los derechos del juego original.

`assets-source/DejaVuSansMono.ttf` es la tipografía utilizada para el texto rasterizado. Su aviso de licencia y atribución se conserva en `assets-source/DejaVu-LICENSE.txt`.

Las dos fuentes base bajo `controllers/mame0276/` se obtuvieron de la etiqueta `mame0276` de MAME:

- https://github.com/mamedev/mame/blob/mame0276/src/mame/tecmo/tecmo.cpp
- https://github.com/mamedev/mame/blob/mame0276/src/mame/mame.lst

El driver conserva su encabezado de licencia BSD-3-Clause y atribución a Nicola Salmoria. El parche añade una definición de juego sin sustituir los controladores originales. `MAME-NOTICE.txt` recoge la licencia de referencia de ese archivo. Los compiladores y emuladores son dependencias externas, no código del proyecto ni binarios instalables suministrados.

La identificación del firmware se realizó sobre una copia `maincode_64` aportada por el usuario. No se incluye esa imagen ni una imagen decodificada en este paquete. Sí se incluyen el informe, el script de lectura, los hashes y las limitaciones. No se identificó un SDK o las fuentes completas de ese firmware que permitan compilar su núcleo.

REA 6.5.0 produjo la evidencia de inventario del ZIP nativo histórico, no una prueba de juego. Para el firmware original devolvió formato no soportado; la integración de firmware requería Binwalk. Se conservan esos resultados y no se cuentan como pruebas superadas ni como decompilación.
