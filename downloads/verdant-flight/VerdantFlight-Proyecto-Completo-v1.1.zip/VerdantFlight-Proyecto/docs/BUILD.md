# Compilación y empaquetado

Todos los scripts trabajan desde la raíz que calculan a partir de su propia ubicación; no necesitan las rutas `/workspace` de la máquina de desarrollo. Los registros históricos sí conservan rutas de aquella ejecución como evidencia.

## Dependencias

La compilación realizada usó Python 3.12.14, Pillow 12.3.0 y SDCC 4.5.0 con `sdasz80` y bibliotecas para Z80. La tipografía utilizada está incluida, con su aviso de licencia. Los compiladores, MAME y FFmpeg no se incluyen como binarios en el proyecto.

En Debian 13, los nombres de paquetes de compilación son `sdcc`, `sdcc-libraries`, `python3-venv` y, para las pruebas, `mame`, `ffmpeg` y `patch`. Se usó MAME `0.276+dfsg.1-1+deb13u1`. Una versión que ofrezca otro repositorio puede diferir; `evidence/current/results.json` identifica lo que realmente se ejecutó. Las instrucciones de instalación de paquetes en otro ordenador no han sido ejecutadas como parte de estas pruebas.

## Construir

```sh
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements-build.txt
python3 tools/build.py
```

Si SDCC está extraído en una carpeta propia:

```sh
python3 tools/build.py \
  --sdcc /ruta/sdcc/bin/sdcc \
  --assembler /ruta/sdcc/bin/sdasz80 \
  --sdcc-lib /ruta/sdcc/share/sdcc/lib/z80
```

También se aceptan `SDCC_BIN`, `SDASZ80_BIN` y `SDCC_LIB` como variables de entorno. En Windows, usa `python` y los ejecutables adecuados; ese sistema anfitrión no se ha probado. `build.sh` es un wrapper opcional para sistemas con shell POSIX.

La construcción regenera assets y paletas, ensambla `crt0.s`, compila `game.c`, valida los registros Intel HEX y rechaza código que invada RAM. Después crea los tres perfiles ZIP, la tabla de correspondencias y el parche de controlador con los hashes actuales.

El ZIP original en `inputs/geminib-original.zip` se valida contra SHA-256 antes de usarlo. Aporta el driver de audio, las muestras, el banco y una imagen alternativa no cargada. Cambiar de conjunto original requiere revisar esa entrada y no es una reconstrucción equivalente.

## Comprobar artefactos

```sh
python3 tools/verify_project.py
```

Se comprueban el ZIP original, los tres perfiles, los tamaños, contenido idéntico entre perfiles, hashes, vectores, las 17 entradas del catálogo de firmware y los hashes de la definición nueva. La comprobación del parche de MAME es una aplicación en seco sobre las dos fuentes de referencia suministradas; no compila MAME.

`build/rom-manifest.json` registra el CRC y SHA-256 de cada ROM actual. `docs/rom-mapping.csv` distingue el CRC actual del que espera el firmware original. No se fuerzan colisiones ni se eliminan comprobaciones de integridad.

## Controlador independiente: sólo fuentes, no probado en ejecución

`controllers/mame0276/verdantflight.patch` añade `ROM_START(verdantflight)`, una entrada de juego con título Verdant Flight y el registro en `mame.lst`. Conserva los juegos originales. Sus hashes se regeneran al compilar el juego.

Para un desarrollador con las fuentes y dependencias de MAME 0.276, el flujo orientativo es:

```sh
git clone --depth 1 --branch mame0276 https://github.com/mamedev/mame.git
cd mame
git apply /ruta/al/proyecto/controllers/mame0276/verdantflight.patch
make SUBTARGET=verdant SOURCES=src/mame/tecmo/tecmo.cpp REGENIE=1 -j2
```

La clonación y compilación de ese MAME personalizado **no se realizaron** en esta entrega. El nombre y la ubicación del ejecutable resultante dependen de la plataforma y del build. Con él, el identificador sería `verdantflight` y la ruta de ROM `dist/named` del proyecto.

Este parche no se aplica a `maincode_64` ni a otros núcleos de FBA/MAME. Un archivo `.inc` no es un plugin que MAME cargue al arrancar.

## Reconstrucción comprobada y cambios

Antes de corregir el eje vertical, el nuevo flujo con tipografía incluida reprodujo el ZIP histórico SHA-256 `eb0e8e95ab01fbb1e3f071155423283efddb22dc62559dac10f6a5b661f5dcc4`. La versión actual corrige esa entrada y se ha reconstruido y probado por separado. Sus hashes actuales están en el manifiesto y en los resultados de pruebas; no se asignan los resultados antiguos al binario nuevo.

## Verificar y volver a crear el ZIP del proyecto

Antes de recompilar, comprueba la integridad de la entrega:

```sh
python3 tools/check_bundle.py
```

`FILES-SHA256.txt` describe los archivos suministrados; tras recompilar pueden cambiar metadatos generados con rutas del nuevo anfitrión. Para empaquetar ese estado nuevo:

```sh
python3 tools/make_project_zip.py --output /ruta/VerdantFlight-Proyecto.zip
```

El ZIP del proyecto y su SHA-256 externo incluyen las fuentes, entradas de ROM, salidas compiladas, tablas y evidencias. No incluyen un compilador o MAME preinstalado, el firmware M15 original ni una imagen decodificada. Las carpetas temporales de MAME (`cfg`, `snap`) y entornos virtuales quedan fuera.
