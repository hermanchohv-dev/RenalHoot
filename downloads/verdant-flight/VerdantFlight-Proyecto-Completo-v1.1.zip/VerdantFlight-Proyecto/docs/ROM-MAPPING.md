# Correspondencia de ROM

Generada desde `inputs/rom-layout.json` y el binario compilado. `—` indica archivo extra no cargado.

La columna MAME es el nombre esperado por el controlador; el ZIP histórico conserva `geminib/G-2.6d` (mayúscula). Esa variante fue aceptada en la prueba de MAME 0.276. El candidato M15 usa nombres planos exactos. Los CRC nativos completos y los esperados en firmware se incluyen en `rom-mapping.csv` y `build/rom-manifest.json`.

| Función | Bytes | MAME 0.276 (`geminib`) | Catálogo M15 (`geminib`) | Conjunto propio (`verdantflight`) |
|---|---:|---|---|---|
| CPU principal | 65536 | `g-2.6d` | `gww2-6c.bin` | `VerdantFlight-Programa.rom` |
| Banco de CPU | 65536 | `gw05-6s.rom` | `gw05-6s.rom` | `VerdantFlight-Bancos.rom` |
| CPU de sonido | 32768 | `gw03-5h.rom` | `gw03-5h.rom` | `VerdantFlight-CPU-Sonido.rom` |
| Texto | 32768 | `gw02-3h.rom` | `gw02-3h.rom` | `VerdantFlight-Texto.rom` |
| Sprites 1 | 65536 | `gw06-1c.rom` | `gw06-1c.rom` | `VerdantFlight-Sprites-1.rom` |
| Sprites 2 | 65536 | `gw07-1d.rom` | `gw07-1d.rom` | `VerdantFlight-Sprites-2.rom` |
| Sprites 3 | 65536 | `gw08-1f.rom` | `gw08-1f.rom` | `VerdantFlight-Sprites-3.rom` |
| Sprites 4 | 65536 | `gw09-1h.rom` | `gw09-1h.rom` | `VerdantFlight-Sprites-4.rom` |
| Primer plano 1 | 65536 | `gw10-1n.rom` | `gw10-1n.rom` | `VerdantFlight-Primer-Plano-1.rom` |
| Primer plano 2 | 65536 | `gw11-2na.rom` | `gw11-2na.rom` | `VerdantFlight-Primer-Plano-2.rom` |
| Primer plano 3 | 65536 | `gw12-2nb.rom` | `gw12-2nb.rom` | `VerdantFlight-Primer-Plano-3.rom` |
| Primer plano 4 | 65536 | `gw13-3n.rom` | `gw13-3n.rom` | `VerdantFlight-Primer-Plano-4.rom` |
| Fondo 1 | 65536 | `gw14-1r.rom` | `gw14-1r.rom` | `VerdantFlight-Fondo-1.rom` |
| Fondo 2 | 65536 | `gw15-2ra.rom` | `gw15-2ra.rom` | `VerdantFlight-Fondo-2.rom` |
| Fondo 3 | 65536 | `gw16-2rb.rom` | `gw16-2rb.rom` | `VerdantFlight-Fondo-3.rom` |
| Fondo 4 | 65536 | `gw17-3r.rom` | `gw17-3r.rom` | `VerdantFlight-Fondo-4.rom` |
| Muestras de sonido | 32768 | `gw01-6a.rom` | `gw01-6a.rom` | `VerdantFlight-Muestras.rom` |
| CPU alternativa no usada | 65536 | `gw04-5s.rom` (extra) | — | `VerdantFlight-Referencia-No-Usada.rom` |

## Integridad frente al firmware M15

| ROM esperada por M15 | CRC en firmware | CRC de Verdant Flight | Coincide |
|---|---|---|---|
| `gww2-6c.bin` | `cd79c5b3` | `5747c998` | NO |
| `gw05-6s.rom` | `5a6947a9` | `5a6947a9` | sí |
| `gw03-5h.rom` | `9bc79596` | `9bc79596` | sí |
| `gw02-3h.rom` | `7acc8d35` | `ccb928be` | NO |
| `gw06-1c.rom` | `4ea51631` | `300872ac` | NO |
| `gw07-1d.rom` | `da42637e` | `d7978eeb` | NO |
| `gw08-1f.rom` | `0b4e8d70` | `d7978eeb` | NO |
| `gw09-1h.rom` | `b65c5e4c` | `d7978eeb` | NO |
| `gw10-1n.rom` | `5e84cd4f` | `d7978eeb` | NO |
| `gw11-2na.rom` | `08b458e1` | `d7978eeb` | NO |
| `gw12-2nb.rom` | `229c9714` | `d7978eeb` | NO |
| `gw13-3n.rom` | `c5dfaf47` | `d7978eeb` | NO |
| `gw14-1r.rom` | `9c10e5b5` | `460f4c51` | NO |
| `gw15-2ra.rom` | `4cd18cfa` | `d7978eeb` | NO |
| `gw16-2rb.rom` | `f911c7be` | `d7978eeb` | NO |
| `gw17-3r.rom` | `79a9ce25` | `d7978eeb` | NO |
| `gw01-6a.rom` | `d78afa05` | `d78afa05` | sí |

Que los nombres coincidan no prueba que el cargador acepte CRC distintos. El comportamiento de ese cargador no ha sido probado en el M15. No se han forzado colisiones CRC ni cambiado su catálogo de firmware.

