# Hardware compilado y controlador

## Destino del juego

El programa se compila con **SDCC 4.5.0, objetivo `-mz80`**, para la CPU Z80 principal del hardware Tecmo utilizado por Gemini Wing. No es un ejecutable ARM, MIPS, macOS, Windows ni Linux para ejecutar directamente en el Game Stick. El procesador físico del stick ejecuta su emulador; éste debe ejecutar el programa Z80 de las ROM.

La configuración comprobada es `geminib` de **MAME 0.276**, definido en `src/mame/tecmo/tecmo.cpp`. Usa la configuración de máquina `geminib`, entradas `gemini`, clase `tecmo_state`, inicialización `init_gemini` y rotación `ROT90`.

Según esa revisión del controlador, la CPU principal se configura a 8 MHz; la CPU de sonido y el YM3812, a 4 MHz. También está configurado un MSM5205 con reloj de 400 kHz. La temporización de vídeo del bootleg emplea 24,18 MHz/4, 384 puntos por línea y 264 líneas, aproximadamente 59,62 Hz. La zona visible de 256 × 224 se presenta como **224 × 256** al rotar. Son datos del emulador, no mediciones de una placa física.

Revisiones posteriores de MAME cambian el modelado de la placa bootleg, incluido el sonido. No se extiende la validación de 0.276 a esas versiones.

## Enlace y arranque

`src/crt0.s` define reset en `0x0000`, IRQ en `0x0038` y NMI en `0x0066`. Establece SP en `0xcfff`, limpia RAM, selecciona interrupciones IM1 y entra en `main()`. No se usa el arranque estándar de SDCC.

| Zona | Uso |
|---|---|
| `0x0000–0xbfff` | ROM fija, 48 KiB; código enlazado desde `0x0100` |
| `0xc000–0xcfff` | RAM de datos y pila, 4 KiB |
| `0xd000–0xd7ff` | Mapa y atributos del texto |
| `0xd800–0xdbff` | Primer plano |
| `0xdc00–0xdfff` | Fondo |
| `0xe000–0xe7ff` | Paleta xBRG444, 1024 entradas |
| `0xe800–0xefff` | RAM de sprites |
| `0xf000–0xf7ff` | Ventana del banco de ROM |
| `0xf800` lectura | Joystick P1: izquierda=1, derecha=2, abajo=4, arriba=8 |
| `0xf801` lectura | Botones P1; con entradas `gemini`, disparo=2 y especial=1 |
| `0xf805` lectura | Inicio P1, bit 0 |
| `0xf800–0xf805` escritura | Desplazamiento de las capas |
| `0xf806` escritura | Latch de órdenes a la CPU de sonido |
| `0xf807` escritura | Inversión de pantalla |
| `0xf808` escritura | Selección de banco |
| `0xf80b` escritura | Servicio del watchdog |

Los símbolos reales de RAM y el tamaño del código están en `build/verdant.map` y `build/rom-manifest.json`. Las pruebas leen el mapa para no asumir que una dirección seguirá siendo válida tras cambiar el código. El juego no contiene el script de invulnerabilidad de las pruebas.

## Gráficos y sonido

El generador produce sprites y tiles de 4 bits por píxel, texto rotado y tres paletas. Se suministra la fuente DejaVu Sans Mono utilizada para generar los glifos. El primer plano está vacío; fondo y sprites forman la escena.

La CPU de sonido conserva `gw03-5h.rom` y las muestras `gw01-6a.rom`. El código envía órdenes al latch `0xf806`; los comandos se contrastaron con escrituras de una ejecución del Gemini Wing original. La música de fase usa su comando 1. No se ha recuperado una partitura ni escrito un driver de sonido nuevo.

## M15: evidencia y límites

El `maincode_64` aportado contiene etiquetas `M18`, `V6.1.4`, `Aug 6 2025--21:04:09` y rutas de compilación con `runing_o_mips16`, `core_symphony` y `concerto`. Las rutas apuntan a otra arquitectura/entorno de firmware; no son un encabezado de ejecutable que confirme por sí solo el SoC físico del stick.

Se reconstruyó un catálogo arcade `geminib` de 17 registros con formato nombre/tamaño/CRC/tipo compatible con `BurnRomInfo`. Los 17 tamaños y CRC coinciden con las ROM originales aportadas. Esto respalda la presencia de un núcleo de la familia Burn/FBA, pero **no identifica con certeza su versión, su política de CRC ni su compatibilidad de ejecución con esta modificación**. No se ha probado que el dispositivo arranque `maincode_64` en lugar de `maincode_128`.

No requiere un controlador MAME nuevo para la prueba de ordenador con el perfil `geminib`. Para registrar el perfil `verdantflight` sí hace falta añadir su definición al emulador. La definición de MAME 0.276 no es un módulo instalable en el firmware M15.
