# Cambios de esta entrega

## Proyecto auditado, edición 1.1

- Corrección del eje vertical: la lectura `0x04` significa abajo y `0x08` arriba en las entradas del controlador. Las pruebas anteriores sólo cubrían el movimiento lateral.
- Pruebas nuevas sin escrituras RAM para las cuatro direcciones, disparo, consumo de orbe y daño/game over.
- Reejecución de progresión por tres fases/jefes con fixtures explícitos.
- Scripts portables, fuente tipográfica incluida y reconstrucción reproducible.
- Tabla completa de nombres de entrada, MAME, catálogo M15 y perfil renombrado.
- Candidato M15 con `gww2-6c.bin`, sin afirmar compatibilidad de ejecución.
- Perfiles y manifiestos separados; parche de MAME regenerado con los hashes del binario nuevo.

La lógica restante del juego, los gráficos, el arranque y el uso del sonido del arcade se conservan respecto a la fuente nativa anterior. La edición anterior y sus resultados se archivan como históricos; no se sustituyen silenciosamente sus hashes por los actuales.
