# Verdant Flight — proyecto nativo Z80

Entrega completa para estudiar, reconstruir y probar Verdant Flight sobre el hardware Tecmo de Gemini Wing. Incluye fuentes, generador de gráficos, entradas de ROM necesarias, tres perfiles de nombres, pruebas reproducibles y evidencias.

**La edición actual está comprobada en MAME 0.276 sobre Linux x86-64. La ejecución en el Game Stick M15 no está comprobada.** Que ese dispositivo ejecute Gemini Wing confirma la presencia de un emulador de ese hardware, pero no prueba que su cargador acepte este programa modificado, sus CRC o un identificador nuevo.

## Qué archivo usar

| Carpeta | Identificador | Estado |
|---|---|---|
| `dist/mame0276/geminib.zip` | `geminib` | Programa actual probado en MAME 0.276. Avisos de checksum esperados. |
| `dist/m15-candidate/geminib.zip` | `geminib` | Candidato con los 17 nombres exactos del catálogo recuperado de `maincode_64`. NO probado en M15. |
| `dist/named/verdantflight.zip` | `verdantflight` | ROM con nombres VerdantFlight. Requiere añadir un controlador al emulador. El parche de MAME se ha comprobado en seco, sin compilar ni ejecutar ese controlador. |

En los tres perfiles, la pantalla del juego muestra **Verdant Flight**. Las ROM que se corresponden entre perfiles tienen los mismos bytes; sólo cambian los nombres y el contenedor. El candidato M15 omite una ROM alternativa que el controlador no carga.

## Ejecutar lo ya comprobado en un ordenador

Con MAME 0.276 instalado, desde la raíz de este proyecto:

```sh
mame geminib -rompath dist/mame0276 -skip_gameinfo
```

No descomprimas el ZIP de ROM. MAME muestra advertencias `WRONG CHECKSUMS` porque espera el volcado histórico de Gemini Wing. Se conservaron esas comprobaciones durante las pruebas; no se cambió el catálogo del emulador. `-skip_gameinfo` evita la pantalla informativa, no desactiva la auditoría de ROM.

Pulsa **1** para iniciar, flechas para mover, botón 1 para disparar y botón 2 para usar el primer orbe. En las asignaciones habituales de MAME, los botones son Ctrl y Alt izquierdos. P pausa el emulador y Tab abre sus controles.

## Reconstruir y verificar

Requisitos usados: Python 3.12.14, Pillow 12.3.0, SDCC 4.5.0 y su ensamblador `sdasz80` y bibliotecas Z80. El emulador sólo hace falta para las pruebas, no para compilar. El ZIP original aportado está en `inputs/geminib-original.zip` y se valida por SHA-256.

```sh
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements-build.txt
python3 tools/build.py
python3 tools/verify_project.py
python3 tools/run_tests.py --mame /ruta/a/mame
```

Si el compilador no está en PATH, `tools/build.py --help` permite indicar `--sdcc`, `--assembler` y `--sdcc-lib`. No es necesario instalar dependencias dentro de la tarjeta del M15. Las versiones y los comandos de esta entrega se conservan en `build/tool-versions.json` y `evidence/current/results.json`.

## Documentación técnica

- [Hardware, mapa de memoria y controlador](docs/HARDWARE.md).
- [Correspondencia de cada ROM](docs/ROM-MAPPING.md), también en CSV y JSON.
- [Compilación, perfiles y reproducibilidad](docs/BUILD.md).
- [Qué se probó y qué no](docs/TESTS.md).
- [Qué falta para el M15 y protocolo de comprobación](docs/M15.md).
- [Procedencia de datos, audio y licencias](docs/PROVENANCE.md).
- [Cambios respecto a la entrega anterior](docs/CHANGELOG.md).

La música y los efectos reutilizan el programa y datos de sonido aportados con Gemini Wing; no son una nueva composición. El arte y la lógica del juego son una adaptación nueva en C/Z80, distinta del HTML inicial. Esta versión tiene tres fases y jefes, pero no reproduce la iluminación vectorial ni los controles táctiles de la versión web.

El proyecto no incluye ni modifica `maincode_64`, `maincode_128`, un firmware para flashear o un instalador validado para M15. El análisis estático de la copia de firmware se incluye como evidencia, con sus límites.
