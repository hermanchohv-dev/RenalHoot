local base=assert(os.getenv('VERDANT_TEST_DIR'))
local A=dofile(assert(os.getenv('VERDANT_MAP')))
local m=manager.machine
local mem=m.devices[':maincpu'].spaces['program']
local frame=0
local log=assert(io.open(base..'/input-results.txt','w'))
local trace=assert(io.open(base..'/runtime.tsv','w'))
local checks={left=false,right=false,up=false,down=false,fire=false,orb=false,death=false}
local startx,starty,lastx,lasty,orbs
local function note(s)log:write(s..'\n');log:flush()end
local function input(name,value)
 for _,p in pairs(m.ioport.ports) do for _,f in pairs(p.fields) do if f.name==name then f:set_value(value) end end end
end
local function check(name,value)
 assert(value,name..' failed');checks[name]=true;note('PASS '..name)
end
emu.register_frame_done(function()
 frame=frame+1
 if frame==60 then m.screens[':screen']:snapshot(base..'/title.png') end
 if frame==120 then input('1 Player Start',1) end
 if frame==125 then input('1 Player Start',0);input('P1 Button 1',1);check('start',mem:read_u8(A.mode)==1) end
 if frame==190 then
  local active=false
  for i=0,13 do if mem:read_u8(A.shots+i*A.object_size+4)>0 then active=true end end
  check('fire',active)
 end
 if frame==200 then startx=mem:read_u8(A.px);input('P1 Left',1) end
 if frame==210 then input('P1 Left',0);lastx=mem:read_u8(A.px);check('left',lastx<startx);input('P1 Right',1) end
 if frame==220 then input('P1 Right',0);check('right',mem:read_u8(A.px)>lastx) end
 if frame==230 then starty=mem:read_u8(A.py);input('P1 Up',1) end
 if frame==240 then input('P1 Up',0);lasty=mem:read_u8(A.py);check('up',lasty<starty);input('P1 Down',1) end
 if frame==250 then input('P1 Down',0);check('down',mem:read_u8(A.py)>lasty) end
 if frame==300 then orbs=mem:read_u8(A.norb);input('P1 Button 2',1) end
 if frame==310 then input('P1 Button 2',0);check('orb',mem:read_u8(A.norb)==orbs-1) end
 if frame==500 then m.screens[':screen']:snapshot(base..'/gameplay.png') end
 if frame%30==0 then
  trace:write(string.format('%d\t%d\t%d\t%d\t%d\t%d\t%d\n',frame,mem:read_u8(A.mode),mem:read_u8(A.lives),mem:read_u8(A.px),mem:read_u8(A.py),mem:read_u8(A.norb),mem:read_u16(A.score)))
 end
 if mem:read_u8(A.mode)==3 and mem:read_u8(A.lives)==0 and not checks.death then
  checks.death=true;note('PASS natural damage and game over');m.screens[':screen']:snapshot(base..'/game-over.png')
 end
 if frame>=3000 then
  for _,name in ipairs({'left','right','up','down','fire','orb','death'}) do assert(checks[name],'missing '..name) end
  note('PASS: input suite without RAM writes');log:close();trace:close();m:exit()
 end
end,'frame')
