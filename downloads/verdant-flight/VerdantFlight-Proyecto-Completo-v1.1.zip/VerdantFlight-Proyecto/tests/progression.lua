local base=assert(os.getenv("VERDANT_TEST_DIR"))
local A=dofile(assert(os.getenv("VERDANT_MAP")))
local m=manager.machine
local mem=m.devices[":maincpu"].spaces["program"]
local frame=0
local checks={movement=false,fan=false,shield=false,beam=false,nova=false,stages={},bosses={}}
local function input(name,value)
 for _,p in pairs(m.ioport.ports) do for _,f in pairs(p.fields) do if f.name==name then f:set_value(value) end end end
end
local out=io.open(base..'/full-results.txt','w')
local completed=false
local function log(s)out:write(s..'\n');out:flush()end
emu.register_frame_done(function()
 frame=frame+1
 local mode=mem:read_u8(A.mode)
 local stage=mem:read_u8(A.stage)
 if frame==60 then m.screens[':screen']:snapshot(base..'/final-title.png') end
 if frame==120 then input('1 Player Start',1) end
 if frame==125 then input('1 Player Start',0);input('P1 Button 1',1) end
 if mode==1 then
  -- Test fixture: invulnerability isolates ability/progression checks from dodging.
  mem:write_u8(A.inv,200)
  if not checks.stages[stage] then
   checks.stages[stage]=true;log('ENTER STAGE '..(stage+1))
   m.screens[':screen']:snapshot(base..'/stage-'..(stage+1)..'.png')
  end
  if frame==200 then input('P1 Left',1) end
  if frame==220 then input('P1 Left',0);checks.movement=mem:read_u8(A.px)<100;log('MOVEMENT '..tostring(checks.movement)) end
  if frame==240 then input('P1 Button 2',1) end
  if frame==250 then input('P1 Button 2',0);checks.fan=mem:read_u8(A.norb)==2;log('FAN '..tostring(checks.fan)) end
  if frame==300 then mem:write_u8(A.orbs,3);mem:write_u8(A.norb,1);input('P1 Button 2',1) end
  if frame==310 then input('P1 Button 2',0);checks.shield=mem:read_u8(A.shield)>0;log('SHIELD '..tostring(checks.shield)) end
  if frame==350 then mem:write_u8(A.orbs,2);mem:write_u8(A.norb,1);input('P1 Button 2',1) end
  if frame==360 then input('P1 Button 2',0);checks.beam=mem:read_u8(A.beam)>0;log('BEAM '..tostring(checks.beam)) end
  if frame==400 then mem:write_u8(A.orbs,1);mem:write_u8(A.norb,1);input('P1 Button 2',1) end
  if frame==410 then input('P1 Button 2',0);checks.nova=mem:read_u8(A.norb)==0;log('NOVA '..tostring(checks.nova)) end
  if frame==1000 then m.screens[':screen']:snapshot(base..'/final-gameplay.png') end
  if mem:read_u8(A.bossactive)==1 then
   if not checks.bosses[stage] then
    checks.bosses[stage]=true;log('BOSS '..(stage+1));m.screens[':screen']:snapshot(base..'/boss-'..(stage+1)..'.png')
   end
   -- Aim using real directional inputs; boss damage comes from the normal shots.
   local x=mem:read_u8(A.px);local target=mem:read_u8(A.bossx)
   input('P1 Left',x>target+3 and 1 or 0);input('P1 Right',x<target-3 and 1 or 0)
  else
   if frame>410 then input('P1 Left',0);input('P1 Right',0) end
  end
 end
 if mode==3 and stage==2 and not completed then
  completed=true
  assert(checks.movement and checks.fan and checks.shield and checks.beam and checks.nova,'ability check failed')
  assert(checks.stages[0] and checks.stages[1] and checks.stages[2],'missing stage')
  assert(checks.bosses[0] and checks.bosses[1] and checks.bosses[2],'missing boss')
  assert(mem:read_u8(A.lives)>0,'unexpected death')
  log('PASS: victory with all three stages, three bosses, movement and four orb abilities')
  m.screens[':screen']:snapshot(base..'/victory.png');out:close();m:exit()
 end
 if frame>10000 then log('FAIL: timeout mode='..mode..' stage='..stage);out:close();m:exit() end
end,'frame')
