/* Verdant Flight: native Z80 adaptation for Tecmo/Gemini Wing hardware. */
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned int u16;
typedef signed int s16;
#define MEM(a) (*(volatile u8 *)(a))
#define MAXE 10
#define MAXS 14
#define MAXB 18
#include "palette.h"
volatile u8 ticks;
u8 prev,mode,stage,lives,inv,px,py,shotcd,oldbuttons,orbs[8],norb,shield,beam,credits,flash;
u8 escroll,spriteindex,kills,spawncd,orbcd,orbtype,orbX,orbY,bosshp,bossx,bossdir,bosscd,bossactive,transition;
u16 elapsed,score,record,randomstate;
struct Obj {u8 x; s16 y; s8 dx; u8 hp,kind;};
struct Obj enemies[MAXE],shots[MAXS],bullets[MAXB];
u8 abs8(s16 n){return n<0?-n:n;}
u8 rng(void){randomstate=(randomstate<<1)^((randomstate&0x8000)?0xb400:0);return randomstate&255;}
void irq(void) __interrupt {ticks++;}
void sound(u8 n){MEM(0xf806)=n;}
void clear_objects(void){u8 i;for(i=0;i<MAXE;i++)enemies[i].hp=0;for(i=0;i<MAXS;i++)shots[i].hp=0;for(i=0;i<MAXB;i++)bullets[i].hp=0;}
void text(u8 x,u8 y,const char *s){u16 off;while(*s&&x<28){off=((u16)(29-x)<<5)+y;MEM(0xd000+off)=*s++;MEM(0xd400+off)=0;x++;}}
void number(u8 x,u8 y,u16 n){char s[6];s[5]=0;s[4]='0'+n%10;n/=10;s[3]='0'+n%10;n/=10;s[2]='0'+n%10;n/=10;s[1]='0'+n%10;n/=10;s[0]='0'+n%10;text(x,y,s);}
void clear_text(void){u16 i;for(i=0;i<1024;i++){MEM(0xd000+i)=32;MEM(0xd400+i)=0;}}
void palette_stage(void){u8 i;u16 w;for(i=0;i<16;i++){w=back_palette[stage*16+i];MEM(0xe600+(u16)i*2)=w>>8;MEM(0xe601+(u16)i*2)=w;}}
void hud(void){text(1,1,"SCORE");number(1,2,score);text(10,1,"SECTOR");MEM(0xd000+((u16)(29-12)<<5)+2)='1'+stage;text(21,1,"LIFE");MEM(0xd000+((u16)(29-23)<<5)+2)='0'+lives;text(1,30,"ORBS");MEM(0xd000+((u16)(29-6)<<5)+30)='0'+norb;}
void sprite(u8 x,s16 y,u8 code,u8 size,u8 color){volatile u8 *s;if(y<0||y>255)return;s=(volatile u8 *)(0xe800+(u16)spriteindex*8);s[0]=4;s[1]=code;s[2]=size;s[3]=color;s[4]=239-x-(4<<size);s[5]=(u8)y-(4<<size);s[6]=0;s[7]=0;spriteindex++;}
void sprites(void){u8 i; spriteindex=0;if(mode!=3){if(!inv||(ticks&4))sprite(px,py,(ticks&8)?160:0,2,0);if(shield)sprite(px,py,144,2,4);for(i=0;i<norb;i++)sprite(px+((i&1)?3:-3),py+18+i*6,24,0,orbs[i]+4);}
for(i=0;i<MAXE;i++)if(enemies[i].hp)sprite(enemies[i].x,enemies[i].y,enemies[i].kind?20:16,1,enemies[i].kind+1);
for(i=0;i<MAXS;i++)if(shots[i].hp)sprite(shots[i].x,shots[i].y,25,0,shots[i].kind?6:0);
for(i=0;i<MAXB;i++)if(bullets[i].hp)sprite(bullets[i].x,bullets[i].y,26,0,1);
if(orbcd==0&&orbY<250)sprite(orbX,orbY,24,0,orbtype+4);
if(bossactive)sprite(bossx,55,64,3,2+stage);
if(flash)sprite(px,py,128,1,1);
for(i=spriteindex;i<100;i++)MEM(0xe800+(u16)i*8)=0;}
void init(void){u16 i,w;u8 row,col,k;randomstate=0xace1;px=112;py=205;stage=0;mode=0;credits=0;norb=3;orbs[0]=0;orbs[1]=1;orbs[2]=2;lives=3;orbcd=1;orbY=255;
for(i=0;i<0x800;i++)MEM(0xe800+i)=0;
for(i=0;i<1024;i++){w=0; if(i<256)w=sprite_palette[i];if(i>=256&&i<272)w=text_palette[i-256];MEM(0xe000+i*2)=w>>8;MEM(0xe001+i*2)=w;}
palette_stage();clear_text();
for(i=0;i<1024;i++)MEM(0xd800+i)=0;
for(row=0;row<16;row++)for(col=0;col<32;col++){i=((u16)row<<5)+col;k=(row<4||row>12)?(2+(rng()&3)):1;MEM(0xdc00+i)=k;MEM(0xde00+i)=0;}
MEM(0xf800)=0;MEM(0xf801)=0;MEM(0xf802)=0;MEM(0xf803)=0;MEM(0xf804)=0;MEM(0xf805)=0;MEM(0xf807)=0;
text(4,7,"V E R D A N T");text(7,10,"F L I G H T");text(5,14,"NATIVE ARCADE EDITION");text(5,17,"THREE LIVING WORLDS");text(4,19,"COLLECT AND FIRE ORBS");text(6,24,"PRESS 1 TO START");text(3,27,"BUTTON 1 FIRE  2 ORB");}
void start(void){u8 i;clear_text();clear_objects();mode=1;stage=0;lives=3;score=0;kills=0;norb=3;orbs[0]=0;orbs[1]=1;orbs[2]=2;px=112;py=211;inv=120;shield=0;beam=0;bosshp=0;bossactive=0;transition=0;elapsed=0;escroll=0;shotcd=0;spawncd=30;orbcd=180;orbY=255;sound(1);palette_stage();hud();for(i=0;i<8;i++)MEM(0xe800+(u16)i*8)=0;}
void shot(u8 x,s16 y,s8 dx,u8 power){u8 i;for(i=0;i<MAXS;i++)if(!shots[i].hp){shots[i].x=x;shots[i].y=y;shots[i].dx=dx;shots[i].hp=power;shots[i].kind=power>1;break;}}
void enemyshot(u8 x,s16 y,s8 dx){u8 i;for(i=0;i<MAXB;i++)if(!bullets[i].hp){bullets[i].x=x;bullets[i].y=y;bullets[i].dx=dx;bullets[i].hp=1;break;}}
void gameover(u8 victory){mode=3;clear_text();if(victory){text(4,10,"THE SKY BREATHES AGAIN");text(8,14,"FLIGHT COMPLETE");sound(0x25);}else{text(8,11,"FLIGHT ENDED");sound(0x13);}text(8,17,"SCORE");number(14,17,score);text(5,23,"PRESS 1 TO FLY AGAIN");if(score>record)record=score;}
void hit(void){if(inv||shield)return;flash=15;sound(0x13);if(lives)lives--;if(!lives){gameover(0);return;}inv=120;if(norb>1)norb--;hud();}
void special(void){u8 i,k;if(!norb)return;k=orbs[0];for(i=1;i<norb;i++)orbs[i-1]=orbs[i];norb--;sound(0x12);
if(k==0){for(i=0;i<5;i++)shot(px+(i-2)*5,py-15,(s8)i-2,3);}else if(k==1){for(i=0;i<MAXE;i++)if(enemies[i].hp){enemies[i].hp=0;score+=100;}for(i=0;i<MAXB;i++)bullets[i].hp=0;if(bossactive)bosshp=bosshp>40?bosshp-40:0;flash=20;}else if(k==2){beam=120;}else{shield=240;}hud();}
void spawn(void){u8 i;for(i=0;i<MAXE;i++)if(!enemies[i].hp){enemies[i].hp=2+stage;enemies[i].kind=rng()&1;enemies[i].x=24+(rng()%176);enemies[i].y=4;enemies[i].dx=(rng()&1)?1:-1;break;}}
void collect(void){if(norb<8)orbs[norb++]=orbtype;else score+=200;sound(0x30);orbY=255;orbcd=180;hud();}
void boss_dead(void){u8 i;bossactive=0;score+=3000;clear_objects();transition=120;elapsed=0;flash=20;if(lives<5)lives++;for(i=0;i<4;i++)enemyshot(bossx,60,(s8)i-2);sound(0x13);hud();}
void step(void){u8 joy,buttons,i,j;struct Obj *e,*s,*b;u8 sys=MEM(0xf805);MEM(0xf80b)=0;
if(mode==0||mode==3){if(sys&1){start();return;}if(mode==0&&!credits&&ticks==90){sound(1);credits=1;}if((ticks&1)==0){escroll++;MEM(0xf803)=escroll;}sprites();return;}
joy=MEM(0xf800);buttons=MEM(0xf801);
if((joy&1)&&px>18)px-=2;if((joy&2)&&px<206)px+=2;if((joy&8)&&py>42)py-=2;if((joy&4)&&py<231)py+=2;
if(inv)inv--;if(shield)shield--;if(flash)flash--;if(shotcd)shotcd--;
if((buttons&2)&&!shotcd){shot(px-5,py-17,0,beam?4:1);shot(px+5,py-17,0,beam?4:1);shotcd=8;if((ticks&15)==0)sound(0x10);}
if((buttons&1)&&!(oldbuttons&1))special();oldbuttons=buttons;if(beam)beam--;
if(transition){transition--;if(!transition){if(stage==2){gameover(1);return;}stage++;elapsed=0;palette_stage();sound(1);hud();}}
else elapsed++;
if((ticks&1)==0){escroll++;MEM(0xf803)=escroll;}
if(!transition&&!bossactive){if(spawncd)spawncd--;else{spawn();spawncd=35-stage*5;}if(elapsed>=1440){bossactive=1;bosshp=100+stage*40;bossx=112;bossdir=1;bosscd=20;}}
if(orbcd){orbcd--;if(!orbcd){orbY=10;orbX=30+(rng()%164);orbtype=rng()&3;}}
else {if((ticks&1)==0)orbY++;if(orbY>=245){orbY=255;orbcd=150;}else if(abs8((s16)orbX-px)<20&&abs8((s16)orbY-py)<20)collect();}
for(i=0;i<MAXE;i++){e=&enemies[i];if(!e->hp)continue;e->y++;if(e->kind&&(ticks&1))e->x+=e->dx;if(e->x<18||e->x>206)e->dx=-e->dx;if(e->y>251){e->hp=0;continue;}if((ticks&63)==i*4&&e->y<190)enemyshot(e->x,e->y,px<e->x?-1:1);if(abs8((s16)e->x-px)<17&&abs8(e->y-py)<18)hit();}
for(i=0;i<MAXS;i++){s=&shots[i];if(!s->hp)continue;s->y-=5;s->x+=s->dx;if(s->y<5||s->x<5||s->x>219){s->hp=0;continue;}for(j=0;j<MAXE;j++){e=&enemies[j];if(e->hp&&abs8((s16)e->x-s->x)<13&&abs8(e->y-s->y)<14){if(e->hp>s->hp)e->hp-=s->hp;else{e->hp=0;score+=100;kills++;if((kills&3)==0&&orbcd){orbcd=0;orbX=e->x;orbY=e->y;orbtype=rng()&3;}}s->hp=0;break;}}
if(s->hp&&bossactive&&abs8((s16)bossx-s->x)<29&&s->y<80&&s->y>24){bosshp=bosshp>s->hp?bosshp-s->hp:0;s->hp=0;}}
for(i=0;i<MAXB;i++){b=&bullets[i];if(!b->hp)continue;b->y+=2;b->x+=b->dx;if(b->y>251||b->x<4||b->x>220){b->hp=0;continue;}if(abs8((s16)b->x-px)<8&&abs8(b->y-py)<10){b->hp=0;hit();}}
if(bossactive){if(abs8((s16)bossx-px)<30&&abs8((s16)py-55)<27)hit();if((ticks&1)==0){bossx+=bossdir;if(bossx<45||bossx>179)bossdir=-bossdir;}if(bosscd)bosscd--;else{for(i=0;i<5;i++)enemyshot(bossx,78,(s8)i-2);bosscd=40-stage*6;}if(!bosshp)boss_dead();}
if((ticks&15)==0)hud();sprites();}
void main(void){init();__asm ei __endasm;for(;;){__asm halt __endasm;if(prev!=ticks){prev=ticks;step();}}}
