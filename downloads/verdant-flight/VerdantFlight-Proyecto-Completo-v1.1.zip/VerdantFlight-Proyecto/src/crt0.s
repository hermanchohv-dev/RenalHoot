.module crt0
.globl _main
.globl _irq
.area _HEADER (ABS)
.org 0x0000
 di
 jp init
.org 0x0038
 jp _irq
.org 0x0066
 retn
.org 0x0080
init:
 ld sp,#0xcfff
 xor a
 ld hl,#0xc000
 ld de,#0xc001
 ld bc,#0x0ffe
 ld (hl),a
 ldir
 im 1
 call _main
haltloop:
 halt
 jr haltloop
.area _CODE
.area _INITIALIZER
.area _GSINIT
.area _GSFINAL
.area _DATA
.area _BSEG
.area _BSS
.area _HEAP
