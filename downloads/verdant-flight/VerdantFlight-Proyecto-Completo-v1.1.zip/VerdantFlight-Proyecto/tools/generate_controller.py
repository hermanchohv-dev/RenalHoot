from pathlib import Path
import difflib,json,re
ROOT=Path(__file__).resolve().parent.parent
p=ROOT/'controllers/mame0276'
manifest=json.loads((ROOT/'build/rom-manifest.json').read_text())
roms={r['mame_name']:r for r in manifest['roms'] if r['m15_name']}
source=(p/'base-tecmo.cpp').read_text()
block='ROM_START( verdantflight )'+source.split('ROM_START( geminib )')[1].split('ROM_END')[0]+'ROM_END\n'
import zipfile,hashlib
with zipfile.ZipFile(ROOT/'dist/named/verdantflight.zip') as z:
 def sub(m):
  row=roms[m[1]];name=row['named_name'];data=z.read(name)
  return 'ROM_LOAD( "'+name+'"'+m[2]+f"CRC({zipfile.crc32(data):08x}) SHA1({hashlib.sha1(data).hexdigest()})"
 block=re.sub(r'ROM_LOAD\(\s*"([^"]+)"(.*?)CRC\([0-9a-f]+\) SHA1\([0-9a-f]+\)',sub,block)
block+='\nGAME( 2026, verdantflight, 0, geminib, gemini, tecmo_state, init_gemini, ROT90, "Homebrew", "Verdant Flight", MACHINE_SUPPORTS_SAVE )\n'
marker='GAME( 1986, rygar,'
if source.count(marker)!=1:raise ValueError('Unexpected base driver')
modified=source.replace(marker,block+'\n'+marker,1)
patch=''.join(difflib.unified_diff(source.splitlines(True),modified.splitlines(True),fromfile='a/src/mame/tecmo/tecmo.cpp',tofile='b/src/mame/tecmo/tecmo.cpp'))
lst=(p/'base-mame.lst').read_text();start=lst.index('@source:tecmo/tecmo.cpp');end=lst.find('@source:',start+10)
if end<0:end=len(lst)
newlst=lst[:end]+'verdantflight                   // Native Verdant Flight homebrew\n\n'+lst[end:]
patch+=''.join(difflib.unified_diff(lst.splitlines(True),newlst.splitlines(True),fromfile='a/src/mame/mame.lst',tofile='b/src/mame/mame.lst'))
(p/'verdantflight.patch').write_text(patch);(p/'verdantflight.inc').write_text(block)
print('Generated MAME 0.276 source patch; compilation/execution of custom driver NOT performed')
