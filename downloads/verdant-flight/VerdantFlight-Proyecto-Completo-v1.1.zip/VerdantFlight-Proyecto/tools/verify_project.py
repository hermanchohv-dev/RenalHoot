from pathlib import Path
import hashlib,json,re,shutil,struct,subprocess,tempfile,zipfile
ROOT=Path(__file__).resolve().parent.parent
checks=[]
def ok(name,condition):
 if not condition:raise AssertionError(name)
 checks.append(name)
def sha(b):return hashlib.sha256(b).hexdigest()
layout=json.loads((ROOT/'inputs/rom-layout.json').read_text());manifest=json.loads((ROOT/'build/rom-manifest.json').read_text())
ok('original ZIP SHA-256',sha((ROOT/'inputs/geminib-original.zip').read_bytes())==layout['original_sha256'])
profiles={k:zipfile.ZipFile(ROOT/v['path']) for k,v in manifest['profiles'].items()}
for name,z in profiles.items():
 ok(name+' ZIP CRC integrity',z.testzip() is None)
 ok(name+' ZIP SHA-256',sha((ROOT/manifest['profiles'][name]['path']).read_bytes())==manifest['profiles'][name]['sha256'])
rows=manifest['roms'];original=zipfile.ZipFile(ROOT/'inputs/geminib-original.zip')
ok('MAME historical paths and entry order',profiles['mame0276'].namelist()==original.namelist())
ok('M15 candidate exact 17 flat names',profiles['m15-candidate'].namelist()==[r['m15_name'] for r in rows if r['m15_name']])
ok('named profile exact 18 names',profiles['named'].namelist()==[r['named_name'] for r in rows])
for r in rows:
 data=profiles['mame0276'].read(r['source_path']);src=original.read(r['source_path'])
 ok(r['input_name']+' size and native hashes',len(data)==r['size'] and sha(data)==r['native_sha256'] and f'{zipfile.crc32(data):08x}'==r['native_crc32'])
 ok(r['input_name']+' named profile payload identical',profiles['named'].read(r['named_name'])==data)
 if r['m15_name']:ok(r['input_name']+' M15 profile payload identical',profiles['m15-candidate'].read(r['m15_name'])==data)
 if r['input_name'] in ['gw03-5h.rom','gw01-6a.rom','gw05-6s.rom','gw04-5s.rom']:ok(r['input_name']+' original bytes retained',data==src)
fw=json.loads((ROOT/'evidence/firmware/maincode64-report.json').read_text())['arcade_catalog']['entries']
for e in fw:
 r=next(r for r in rows if r['m15_name']==e['name'])
 data=original.read(r['source_path'])
 ok('firmware catalog '+e['name'],len(data)==e['size'] and f'{zipfile.crc32(data):08x}'==e['crc32'])
new=profiles['mame0276'].read('geminib/G-2.6d')
ok('reset and IRQ vectors',new[:2]==b'\xf3\xc3' and new[0x38]==0xc3)
for name,crc,s1 in re.findall(r'ROM_LOAD\(\s*"([^"]+)".*?CRC\(([0-9a-f]+)\) SHA1\(([0-9a-f]+)\)',(ROOT/'controllers/mame0276/verdantflight.inc').read_text()):
 data=profiles['named'].read(name)
 ok('custom driver actual hash '+name,f'{zipfile.crc32(data):08x}'==crc and hashlib.sha1(data).hexdigest()==s1)
patch_status='not run: patch executable absent'
if shutil.which('patch'):
 with tempfile.TemporaryDirectory(prefix='driver-check-',dir=ROOT/'build') as temp:
  t=Path(temp);(t/'src/mame/tecmo').mkdir(parents=True)
  shutil.copyfile(ROOT/'controllers/mame0276/base-tecmo.cpp',t/'src/mame/tecmo/tecmo.cpp');shutil.copyfile(ROOT/'controllers/mame0276/base-mame.lst',t/'src/mame/mame.lst')
  patch=(ROOT/'controllers/mame0276/verdantflight.patch').read_bytes()
  result=subprocess.run(['patch','--dry-run','-p1','-d',str(t)],input=patch,capture_output=True)
  (ROOT/'evidence/current').mkdir(exist_ok=True,parents=True)
  (ROOT/'evidence/current/controller-patch-check.log').write_bytes(result.stdout+result.stderr)
  ok('custom driver patch dry-run (not compilation)',result.returncode==0);patch_status='dry-run passed; NOT compiled or executed'
run=ROOT/'evidence/current/results.json'
if run.exists():
 r=json.loads(run.read_text());ok('current MAME suites passed for this exact ZIP',r['all_passed'] and r['rom_sha256']==manifest['profiles']['mame0276']['sha256'])
result={'static_checks_passed':len(checks),'checks':checks,'custom_driver':patch_status,'m15_runtime':'NOT TESTED','verified_profiles':{k:v['sha256'] for k,v in manifest['profiles'].items()}}
(ROOT/'build/verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
for z in profiles.values():z.close()
original.close()
