"""Portable host-side build; target is Z80, not ARM/MIPS host firmware."""
from pathlib import Path
import argparse,json,os,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--sdcc',default=os.getenv('SDCC_BIN','sdcc'));p.add_argument('--assembler',default=os.getenv('SDASZ80_BIN','sdasz80'));p.add_argument('--sdcc-lib',default=os.getenv('SDCC_LIB'));a=p.parse_args()
def resolve(x):
 y=shutil.which(x)
 if not y:raise SystemExit('Executable not found: '+x)
 return str(Path(y).resolve())
sdcc=resolve(a.sdcc);assembler=resolve(a.assembler)
(ROOT/'build').mkdir(exist_ok=True);(ROOT/'assets').mkdir(exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'tools/build_assets.py')],cwd=ROOT,check=True)
env=dict(os.environ);env['PATH']=str(Path(sdcc).parent)+os.pathsep+env.get('PATH','')
subprocess.run([assembler,'-plosgff','crt0.rel',str(ROOT/'src/crt0.s')],cwd=ROOT/'build',env=env,check=True)
cmd=[sdcc,'-mz80','--no-std-crt0','--code-loc','0x0100','--data-loc','0xc000','--stack-loc','0xcfff','-I'+str(ROOT/'src')]
if a.sdcc_lib:cmd+=['-L'+str(Path(a.sdcc_lib).resolve())]
cmd+=[str(ROOT/'build/crt0.rel'),str(ROOT/'src/game.c'),'-o',str(ROOT/'build/verdant.ihx')]
subprocess.run(cmd,cwd=ROOT/'build',env=env,check=True)
import PIL
version=subprocess.run([sdcc,'--version'],capture_output=True,text=True,check=True).stdout.splitlines()[0]
(ROOT/'build/tool-versions.json').write_text(json.dumps({'compiler':version,'python':sys.version.split()[0],'pillow':PIL.__version__,'target':'Z80 / Tecmo Gemini Wing hardware','flags':cmd[1:cmd.index(str(ROOT/'build/crt0.rel'))]},indent=2)+'\n')
subprocess.run([sys.executable,str(ROOT/'tools/package_roms.py')],cwd=ROOT,check=True)

subprocess.run([sys.executable,str(ROOT/"tools/generate_controller.py")],cwd=ROOT,check=True)
