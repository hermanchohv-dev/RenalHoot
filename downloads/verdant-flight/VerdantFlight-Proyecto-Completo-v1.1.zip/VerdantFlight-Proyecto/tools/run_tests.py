"""Repeatable headless MAME tests. Does not run or alter any M15 firmware."""
from pathlib import Path
import argparse,array,hashlib,json,os,platform,re,shutil,subprocess,sys,wave
ROOT=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--mame',default=os.getenv('MAME_BIN','mame'));p.add_argument('--output',default='evidence/current');a=p.parse_args()
exe=shutil.which(a.mame)
if not exe:raise SystemExit('MAME executable not found')
exe=str(Path(exe).resolve());out=(ROOT/a.output).resolve();out.mkdir(parents=True,exist_ok=True)
text=(ROOT/'build/verdant.map').read_text();addresses={n:int(v,16) for v,n in re.findall(r'^\s*([0-9A-Fa-f]{8})\s+_(\w+)\s+',text,re.M)}
needed=['mode','stage','lives','inv','px','py','orbs','norb','shield','beam','bossx','bossactive','score','shots','bullets']
for name in needed:
 if name not in addresses:raise SystemExit('Missing symbol '+name)
addresses['object_size']=(addresses['bullets']-addresses['shots'])//14
if addresses['object_size']!=6:raise SystemExit('Object layout changed; update test harness before running')
mapfile=out/'addresses.lua';mapfile.write_text('return {'+','.join(f'{k}={addresses[k]}' for k in needed+['object_size'])+'}\n')
version=subprocess.run([exe,'-help'],capture_output=True,text=True).stdout.splitlines()[0]
rom=ROOT/'dist/mame0276/geminib.zip';before=hashlib.sha256(rom.read_bytes()).hexdigest()
results={'emulator':version,'host':platform.platform(),'host_machine':platform.machine(),'rom_sha256':before,'profile':'mame0276','m15_runtime_tested':False,'suites':{}}
for name,seconds,marker in [('inputs',60,'PASS: input suite without RAM writes'),('progression',180,'PASS: victory')]:
 d=out/name;d.mkdir(exist_ok=True)
 env=dict(os.environ);env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',VERDANT_TEST_DIR=str(d),VERDANT_MAP=str(mapfile))
 cmd=[exe,'geminib','-rompath',str(rom.parent),'-video','none','-sound','sdl','-nothrottle','-skip_gameinfo','-noplugins','-autoboot_delay','1','-autoboot_script',str(ROOT/'tests'/f'{name}.lua'),'-seconds_to_run',str(seconds),'-wavwrite',str(d/'audio.wav')]
 with (d/'mame.log').open('w') as log:r=subprocess.run(cmd,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 evidence=d/('input-results.txt' if name=='inputs' else 'full-results.txt');content=evidence.read_text() if evidence.exists() else ''
 passed=r.returncode==0 and marker in content
 with wave.open(str(d/'audio.wav')) as w:
  pcm=w.readframes(w.getnframes());samples=array.array('h',pcm)
  audio={'channels':w.getnchannels(),'rate':w.getframerate(),'frames':w.getnframes(),'seconds':w.getnframes()/w.getframerate(),'peak':max(abs(v) for v in samples),'pcm_sha256':hashlib.sha256(pcm).hexdigest()}
  passed=passed and audio['peak']>0 and audio['rate']==48000
 results['suites'][name]={'passed':passed,'exit_code':r.returncode,'ram_fixture':name=='progression','result_text':content.splitlines(),'audio':audio,'command':cmd}
 if not passed:
  (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');raise SystemExit('Suite failed: '+name+'; inspect '+str(d/'mame.log'))
 # Compress full audio losslessly if FFmpeg exists; retain PCM digest above.
 ff=shutil.which('ffmpeg')
 if ff:
  subprocess.run([ff,'-hide_banner','-loglevel','error','-y','-i',str(d/'audio.wav'),'-c:a','flac',str(d/'audio.flac')],check=True)
  # WAV is a generated run artifact; remove only after verifying a lossless decode.
  decoded=subprocess.run([ff,'-hide_banner','-loglevel','error','-i',str(d/'audio.flac'),'-f','s16le','-'],capture_output=True,check=True).stdout
  if hashlib.sha256(decoded).hexdigest()!=audio['pcm_sha256']:raise SystemExit('FLAC verification failed')
  (d/'audio.wav').unlink()
if hashlib.sha256(rom.read_bytes()).hexdigest()!=before:raise SystemExit('ROM mutated during tests')
results['all_passed']=True;(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
