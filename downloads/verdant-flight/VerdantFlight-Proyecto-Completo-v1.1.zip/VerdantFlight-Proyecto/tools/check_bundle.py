from pathlib import Path
import hashlib,sys
root=Path(__file__).resolve().parent.parent
errors=[];n=0
for line in (root/'FILES-SHA256.txt').read_text().splitlines():
 expected,name=line.split('  ',1);p=root/name
 if p.resolve().is_relative_to(root.resolve()) and p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected:n+=1
 else:errors.append(name)
if errors:raise SystemExit('Bundle integrity failed: '+', '.join(errors))
print('Bundle integrity OK:',n,'files. Run before rebuilding, since generated metadata may change.')
