from pathlib import Path
import argparse,hashlib,os,zipfile
ROOT=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT.parent/'deliverables/VerdantFlight-Proyecto-Completo-v1.1.zip'));a=p.parse_args()
output=Path(a.output).resolve();output.parent.mkdir(parents=True,exist_ok=True)
skip={'.git','.venv','__pycache__','cfg','snap'}
files=sorted(f for f in ROOT.rglob('*') if f.is_file() and not any(x in skip for x in f.relative_to(ROOT).parts) and f.name!='FILES-SHA256.txt' and f.resolve()!=output)
manifest=''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(ROOT).as_posix()+'\n' for f in files)
(ROOT/'FILES-SHA256.txt').write_text(manifest)
files.append(ROOT/'FILES-SHA256.txt')
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files:
  i=zipfile.ZipInfo('VerdantFlight-Proyecto/'+f.relative_to(ROOT).as_posix(),(2026,10,15,0,0,0));i.create_system=3;i.external_attr=(0o100755 if f.suffix=='.sh' else 0o100644)<<16;i.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(i,f.read_bytes())
with zipfile.ZipFile(output) as z:
 if z.testzip() is not None:raise SystemExit('ZIP integrity failure')
digest=hashlib.sha256(output.read_bytes()).hexdigest()
output.with_suffix(output.suffix+'.sha256').write_text(digest+'  '+output.name+'\n')
print(str(output));print('files',len(files),'bytes',output.stat().st_size,'SHA256',digest)
