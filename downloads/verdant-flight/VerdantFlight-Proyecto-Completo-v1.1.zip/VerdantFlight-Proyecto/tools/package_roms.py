"""Build three explicit ROM naming profiles. Does not modify M15 firmware."""
from pathlib import Path
import csv,hashlib,json,sys,zipfile
ROOT=Path(__file__).resolve().parent.parent

def digest(b):return hashlib.sha256(b).hexdigest()
def info(name):
 i=zipfile.ZipInfo(name,(2026,10,15,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.create_system=3;i.external_attr=0o100644<<16;return i

def main():
 layout=json.loads((ROOT/'inputs/rom-layout.json').read_text())
 source=ROOT/'inputs/geminib-original.zip'
 if digest(source.read_bytes())!=layout['original_sha256']:raise ValueError('Original ROM ZIP hash mismatch')
 program=bytearray([255])*65536;used=set();last=0;eof=False
 for line in (ROOT/'build/verdant.ihx').read_text().splitlines():
  if not line:continue
  if not line.startswith(':'):raise ValueError('Invalid Intel HEX record')
  raw=bytes.fromhex(line[1:]);n=raw[0];a=int.from_bytes(raw[1:3],'big');kind=raw[3]
  if len(raw)!=n+5 or sum(raw)&255:raise ValueError('HEX record checksum or length mismatch')
  if kind==0:
   if a+n>0xc000:raise ValueError('Program overlaps RAM at 0xc000')
   if any(i in used for i in range(a,a+n)):raise ValueError('HEX address overlap')
   used.update(range(a,a+n));program[a:a+n]=raw[4:4+n];last=max(last,a+n)
  elif kind==1:eof=True
  else:raise ValueError('Unexpected HEX record type: '+str(kind))
 if not eof or program[0]!=0xf3 or program[1]!=0xc3 or program[0x38]!=0xc3:raise ValueError('Missing EOF, reset vector or IRQ vector')
 replacements={'G-2.6d':bytes(program),'gw02-3h.rom':(ROOT/'assets/text.bin').read_bytes()}
 sprites=(ROOT/'assets/sprites.bin').read_bytes();bg=(ROOT/'assets/background.bin').read_bytes()
 for i,k in enumerate(['gw06-1c.rom','gw07-1d.rom','gw08-1f.rom','gw09-1h.rom']):replacements[k]=sprites[i*65536:(i+1)*65536]
 for i,k in enumerate(['gw14-1r.rom','gw15-2ra.rom','gw16-2rb.rom','gw17-3r.rom']):replacements[k]=bg[i*65536:(i+1)*65536]
 for k in ['gw10-1n.rom','gw11-2na.rom','gw12-2nb.rom','gw13-3n.rom']:replacements[k]=bytes(65536)
 paths={'mame0276':ROOT/'dist/mame0276/geminib.zip','m15-candidate':ROOT/'dist/m15-candidate/geminib.zip','named':ROOT/'dist/named/verdantflight.zip'}
 for path in paths.values():path.parent.mkdir(parents=True,exist_ok=True)
 payloads={};manifest=[]
 with zipfile.ZipFile(source) as src,zipfile.ZipFile(paths['mame0276'],'w',zipfile.ZIP_DEFLATED) as dst:
  for entry in src.infolist():
   original=src.read(entry);k=Path(entry.filename).name;data=replacements.get(k,original)
   if len(data)!=len(original):raise ValueError('ROM length changed: '+k)
   dst.writestr(entry,data)
   if not entry.is_dir():payloads[k]=data
 for profile in ['m15-candidate','named']:
  with zipfile.ZipFile(paths[profile],'w',zipfile.ZIP_DEFLATED) as dst:
   for row in layout['roms']:
    name=row['m15_name'] if profile=='m15-candidate' else row['named_name']
    if name:dst.writestr(info(name),payloads[row['input_name']])
 for row in layout['roms']:
  data=payloads[row['input_name']];r=dict(row)
  r.update(native_crc32=f'{zipfile.crc32(data):08x}',native_sha256=digest(data),matches_m15_catalog_crc=(r['m15_expected_crc32']==f'{zipfile.crc32(data):08x}') if r['m15_name'] else None)
  manifest.append(r)
 result={'program_last_exclusive':last,'roms':manifest,'profiles':{k:{'path':str(v.relative_to(ROOT)),'sha256':digest(v.read_bytes())} for k,v in paths.items()}}
 (ROOT/'build/rom-manifest.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
 with (ROOT/'docs/rom-mapping.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(manifest[0]));w.writeheader();w.writerows(manifest)
 lines=['# Correspondencia de ROM\n','Generada desde `inputs/rom-layout.json` y el binario compilado. `—` indica archivo extra no cargado.\n','La columna MAME es el nombre esperado por el controlador; el ZIP histórico conserva `geminib/G-2.6d` (mayúscula). Esa variante fue aceptada en la prueba de MAME 0.276. El candidato M15 usa nombres planos exactos. Los CRC nativos completos y los esperados en firmware se incluyen en `rom-mapping.csv` y `build/rom-manifest.json`.\n','| Función | Bytes | MAME 0.276 (`geminib`) | Catálogo M15 (`geminib`) | Conjunto propio (`verdantflight`) |','|---|---:|---|---|---|']
 for r in manifest:lines.append(f"| {r['role']} | {r['size']} | `{r['mame_name']}`{' (extra)' if not r['m15_name'] else ''} | `{r['m15_name']}` | `{r['named_name']}` |".replace('`None`','—'))
 lines+=['\n## Integridad frente al firmware M15\n','| ROM esperada por M15 | CRC en firmware | CRC de Verdant Flight | Coincide |','|---|---|---|---|']
 for r in manifest:
  if r['m15_name']:lines.append(f"| `{r['m15_name']}` | `{r['m15_expected_crc32']}` | `{r['native_crc32']}` | {'sí' if r['matches_m15_catalog_crc'] else 'NO'} |")
 lines+=['\nQue los nombres coincidan no prueba que el cargador acepte CRC distintos. El comportamiento de ese cargador no ha sido probado en el M15. No se han forzado colisiones CRC ni cambiado su catálogo de firmware.\n']
 (ROOT/'docs/ROM-MAPPING.md').write_text('\n'.join(lines)+'\n')
 print(json.dumps({'program_last_exclusive':hex(last),'profiles':result['profiles']},indent=2))
if __name__=='__main__':main()
