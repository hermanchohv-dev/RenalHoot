"""Read-only firmware identification. Does not patch, execute or install firmware."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,struct,zipfile,sys,argparse
ROOT=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('firmware');p.add_argument('--output',default='evidence/firmware/reanalysis.json');a=p.parse_args()
source=Path(a.firmware)
report=Path(a.output);report=report if report.is_absolute() else ROOT/report
report.parent.mkdir(parents=True,exist_ok=True)
raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='c04d4674edb7b355c5cf6d2e714d53ed089bfc82f693e3ebf9e018f69f9de899'
key,count=Counter(raw[i:i+64] for i in range(0,len(raw)-64,64)).most_common(1)[0]
d=bytes(b^key[i%64] for i,b in enumerate(raw))
assert b'Aug  6 2025--21:04:09' in d and b'V6.1.4\0' in d and b' M18\0' in d
bias=0x80007ffc
entries=[]
for i in range(17):
 off=0xe24af0+i*16;nameptr,size,crc,flags=struct.unpack_from('<4I',d,off)
 nameoff=nameptr-bias;end=d.index(0,nameoff)
 name=d[nameoff:end].decode('ascii')
 assert 0<len(name)<40
 entries.append(dict(index=i,file_offset=f'0x{off:x}',name=name,size=size,crc32=f'{crc:08x}',flags=f'0x{flags:x}',name_offset=f'0x{nameoff:x}'))
# Cross-check all 17 records against the actual supplied arcade images.
original=ROOT/'inputs/geminib-original.zip'
with zipfile.ZipFile(original) as z:
 for e in entries:
  name='G-2.6d' if e['name']=='gww2-6c.bin' else e['name']
  data=z.read('geminib/'+name)
  assert len(data)==e['size'] and f'{zipfile.crc32(data):08x}'==e['crc32']
result={'file':'maincode_64','size':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'decoding':{'type':'repeating XOR','period_bytes':64,'known_repeated_block_count':count,'verification':'17 reconstructed ROM records match sizes and CRC32 of user-supplied arcade ROM images'},'embedded_labels':{'model':' M18','version':'V6.1.4','build':'Aug  6 2025--21:04:09'},'architecture_evidence':{'status':'inference, not an executable header','source_path_contains':'runing_o_mips16','hardware_family_strings':['core_symphony','concerto']},'arcade_catalog':{'name':'geminib','table_offset':'0xe24af0','driver_record_offset':'0xe24a60','entries':entries,'format':'records match BurnRomInfo name/size/CRC/type layout; exact engine/version not established'},'limitations':['Firmware was not executed or modified','No proof that maincode_64 rather than maincode_128 is active on the device','No M15 hardware runtime validation','No verified firmware-patch or installation method','REA rejected the original unknown format; firmware inspection also lacks Binwalk provider. Decoding and table evidence are from the documented Python analysis, not a successful REA decompilation.']}
report.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
assert source.read_bytes()==raw
print('Read-only identification verified; 17/17 ROM records match. Original upload unchanged.')
