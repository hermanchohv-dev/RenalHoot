from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,random
p=Path(__file__).resolve().parent.parent
random.seed(3107)
layout=[[0,1,4,5,16,17,20,21],[2,3,6,7,18,19,22,23],[8,9,12,13,24,25,28,29],[10,11,14,15,26,27,30,31],[32,33,36,37,48,49,52,53],[34,35,38,39,50,51,54,55],[40,41,44,45,56,57,60,61],[42,43,46,47,58,59,62,63]]
def packed(im):
 b=bytearray()
 for y in range(8):
  for x in range(0,8,2):b.append((im.getpixel((x,y))<<4)|im.getpixel((x+1,y)))
 return b
spr=bytearray(0x40000)
def sprite(base,im):
 im=im.transpose(Image.Transpose.ROTATE_90);n=im.width//8
 for y in range(n):
  for x in range(n):
   off=(base+layout[y][x])*32;spr[off:off+32]=packed(im.crop((x*8,y*8,x*8+8,y*8+8)))
def ship(frame):
 im=Image.new('L',(32,32));d=ImageDraw.Draw(im)
 d.polygon([(15,2),(19,11),(29,25),(21,22),(17,27),(15,21),(11,27),(9,22),(1,25),(11,11)],fill=8,outline=12)
 d.polygon([(4,23),(12,13),(10,22)],fill=5);d.polygon([(27,23),(19,13),(21,22)],fill=5)
 d.ellipse((12,7,18,25),fill=11);d.ellipse((13,6,17,16),fill=3);d.line((14,7,14,12),fill=15)
 d.line((10,25,10,30-frame),fill=14,width=2);d.line((21,25,21,30-frame),fill=14,width=2)
 d.point((6,21),fill=15);d.point((25,21),fill=15);return im
sprite(0,ship(0));sprite(160,ship(2))
for base,moth in [(16,False),(20,True)]:
 im=Image.new('L',(16,16));d=ImageDraw.Draw(im)
 d.polygon([(7,2),(2,1),(0,10),(5,9),(8,15),(11,9),(15,10),(13,1),(9,2)],fill=8,outline=12)
 d.ellipse((6,1,9,14),fill=10);d.line((7,2,7,12),fill=15)
 if moth:d.ellipse((1,3,4,7),fill=3);d.ellipse((11,3,14,7),fill=3)
 sprite(base,im)
for base in [24,25,26]:
 im=Image.new('L',(8,8));d=ImageDraw.Draw(im)
 if base==24:d.ellipse((0,0,7,7),fill=5,outline=12);d.ellipse((2,1,5,4),fill=15)
 elif base==25:d.ellipse((2,0,5,7),fill=12);d.line((3,1,3,6),fill=15)
 else:d.ellipse((1,1,6,6),fill=10);d.point((3,2),fill=15)
 sprite(base,im)
im=Image.new('L',(64,64));d=ImageDraw.Draw(im)
for side in [-1,1]:
 pts=[(32,8),(32+side*17,2),(32+side*30,16),(32+side*26,40),(32+side*13,32),(32,57)]
 d.polygon(pts,fill=7,outline=12)
 for k in range(4):d.line((32+side*5,10+k*7,32+side*24,16+k*4),fill=4,width=1)
 d.ellipse((32+side*18-5,13,32+side*18+5,27),fill=3,outline=11);d.ellipse((32+side*18-2,17,32+side*18+2,23),fill=15)
d.ellipse((25,4,39,57),fill=10,outline=14)
for y in range(12,55,7):d.line((26,y,38,y),fill=4)
d.ellipse((28,44,36,53),fill=15);sprite(64,im)
im=Image.new('L',(16,16));d=ImageDraw.Draw(im)
for i in range(10):
 a=i*math.tau/10;d.line((8,8,8+int(math.cos(a)*7),8+int(math.sin(a)*7)),fill=12 if i%2 else 15)
sprite(128,im)
im=Image.new('L',(32,32));d=ImageDraw.Draw(im);d.ellipse((0,0,31,31),outline=12);d.arc((2,2,29,29),0,140,fill=15);sprite(144,im)
(p/'assets/sprites.bin').write_bytes(spr)
# Background 16x16 tiles packed as four consecutive 8x8 subtiles.
bg=bytearray(0x40000)
for n in range(1,6):
 im=Image.new('L',(16,16),2);d=ImageDraw.Draw(im)
 if n==1:
  d.line((3,0,5,15),fill=3);d.line((10,0,12,15),fill=4);d.point((8,8),fill=6)
 else:
  d.ellipse((-3,-3,18,19),fill=3);d.polygon([(8,0),(15,8),(9,15),(1,9)],fill=6+n)
  d.line((8,1,9,14),fill=12)
  for y in [4,8,12]:d.line((8,y,3,y-2),fill=5);d.line((9,y,13,y-2),fill=5)
 im=im.transpose(Image.Transpose.ROTATE_90)
 for j,(x,y) in enumerate([(0,0),(8,0),(0,8),(8,8)]):bg[n*128+j*32:n*128+(j+1)*32]=packed(im.crop((x,y,x+8,y+8)))
(p/'assets/background.bin').write_bytes(bg)
text=bytearray(0x8000);font=ImageFont.truetype(str(p/'assets-source/DejaVuSansMono.ttf'),8)
for code in range(32,127):
 im=Image.new('L',(8,8));d=ImageDraw.Draw(im);d.text((1,-2),chr(code),font=font,fill=15,stroke_width=0)
 im=im.point(lambda v:15 if v>=6 else 0).transpose(Image.Transpose.ROTATE_90)
 text[code*32:(code+1)*32]=packed(im)
(p/'assets/text.bin').write_bytes(text)
def word(rgb):
 r,g,b=rgb;return ((b//17)<<8)|((r//17)<<4)|(g//17)
pal=[]
colors=[(145,238,179),(255,169,100),(225,143,238),(133,180,255),(80,220,240),(255,195,90),(180,135,255),(150,245,145)]+[(150,210,175)]*8
for color in colors:
 for i in range(16):
  if i==0:pal.append(0);continue
  t=i/15
  rgb=tuple(int((v*.9*t+255*max(0,t-.6)*.7)) for v in color)
  pal.append(word(tuple(min(255,v) for v in rgb)))
backs=[]
for color in [(55,143,101),(75,108,174),(177,119,91)]:
 for i in range(16):backs.append(word(tuple(min(255,int(v*(.16+i*.065))) for v in color)))
textpal=[0]*16;textpal[15]=word((204,255,221))
s='/* Generated xBRG444 palettes. */\n'
for name,a in [('sprite_palette',pal),('back_palette',backs),('text_palette',textpal)]:s+='const u16 '+name+'[]={'+','.join(hex(v) for v in a)+'};\n'
(p/'src/palette.h').write_text(s)
