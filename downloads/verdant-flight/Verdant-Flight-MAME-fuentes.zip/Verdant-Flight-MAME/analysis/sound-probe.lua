local m=manager.machine
local frame=0
local base=os.getenv("GEMINI_RUN_DIR") or "/workspace/gemini-rom-v2/analysis"
local mem=m.devices[":maincpu"].spaces["program"]
local out=assert(io.open(base.."/palette-trace.tsv","w"))
out:write("frame\tpc\thl\tde\tbc\tbank\taddress\tvalue\n")
local sf=io.open(base..'/sound-commands.tsv','w')
sound_watch=mem:install_write_tap(0xf806,0xf806,'sound-watch',function(offset,data,mask) sf:write(string.format('%d\t%02x\n',frame,data));sf:flush() end)
local seen={}
local bank=0
bank_watch=mem:install_write_tap(0xf808,0xf808,"bank-watch",function(offset,data,mask) bank=data end)
palette_watch=mem:install_write_tap(0xe000,0xe7ff,"palette-watch",function(offset,data,mask)
 local cpu=m.devices[":maincpu"]
 local pc=cpu.state["PC"].value
 local hl=cpu.state["HL"].value
 local key=string.format("%04x:%04x",pc,hl)
 if not seen[key] then
  seen[key]=true
  out:write(string.format("%d\t%04x\t%04x\t%04x\t%04x\t%02x\t%04x\t%02x\n",frame,pc,hl,cpu.state["DE"].value,cpu.state["BC"].value,bank,offset,data))
 end
end)
local function input(name,value)
 for _,port in pairs(m.ioport.ports) do
  for _,field in pairs(port.fields) do
   if field.name==name then field:set_value(value) end
  end
 end
end
emu.register_frame_done(function()
 frame=frame+1
 if frame==600 then input("Coin 1",1) end
 if frame==605 then input("Coin 1",0) end
 if frame==1000 then input("1 Player Start",1) end
 if frame==1010 then input("1 Player Start",0) end
 if frame==1020 then
  local f=io.open(base..'/input-fields.txt','w')
  for tag,port in pairs(m.ioport.ports) do for _,field in pairs(port.fields) do f:write(tag..'\t'..field.name..'\n') end end
  f:close()
 end
 if frame==1020 then input("P1 Button 1",1) end
 if frame==300 or frame==900 or frame==1800 or frame==3000 then
  m.screens[":screen"]:snapshot(string.format(base..'/screen-%04d.png',frame))
  local f=assert(io.open(string.format(base..'/palette-%04d.bin',frame),'wb'))
  for addr=0xe000,0xe7ff do f:write(string.char(mem:read_u8(addr))) end
  f:close()
 end
 if frame>=3200 then out:close();m:exit() end
end,"frame")
