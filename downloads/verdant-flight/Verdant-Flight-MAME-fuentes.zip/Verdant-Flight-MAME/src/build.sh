#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
if [ "$#" -ne 1 ]; then echo 'Uso: src/build.sh /ruta/al/geminib.zip ORIGINAL' >&2; exit 1; fi
input_zip=$(realpath "$1")
mkdir -p build assets analysis download
python3 src/build_assets.py
: "${SDCC_BIN:=sdcc}"
: "${SDASZ80_BIN:=sdasz80}"
: "${SDCC_LIB:=/usr/share/sdcc/lib/z80}"
cd build
"$SDASZ80_BIN" -plosgff crt0.rel ../src/crt0.s
"$SDCC_BIN" -mz80 --no-std-crt0 --code-loc 0x0100 --data-loc 0xc000 --stack-loc 0xcfff -L"$SDCC_LIB" -I../src crt0.rel ../src/game.c -o verdant.ihx
cd ..
python3 src/package_rom.py "$input_zip"
