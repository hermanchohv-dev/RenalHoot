from pathlib import Path
import zipfile,hashlib,json,sys
p=Path(__file__).resolve().parent.parent
rom=bytearray([255])*65536;used=[]
for line in (p/'build/verdant.ihx').read_text().splitlines():
 raw=bytes.fromhex(line[1:]);assert sum(raw)&255==0
 n=raw[0];a=int.from_bytes(raw[1:3],'big');kind=raw[3]
 if kind==0:
  assert a+n<0xc000
  rom[a:a+n]=raw[4:4+n];used.append((a,a+n))
replacements={'G-2.6d':bytes(rom),'gw02-3h.rom':(p/'assets/text.bin').read_bytes()}
for n in range(4):
 replacements[f'gw0{6+n}-1'+['c','d','f','h'][n]+'.rom']=(p/'assets/sprites.bin').read_bytes()[n*65536:(n+1)*65536]
for n,name in enumerate(['gw14-1r.rom','gw15-2ra.rom','gw16-2rb.rom','gw17-3r.rom']):replacements[name]=(p/'assets/background.bin').read_bytes()[n*65536:(n+1)*65536]
for name in ['gw10-1n.rom','gw11-2na.rom','gw12-2nb.rom','gw13-3n.rom']:replacements[name]=bytes(65536)
source=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/attachments/f9e45bdd-f216-43ce-8b85-e8111ef77b02/geminib.zip')
manifest=[]
with zipfile.ZipFile(source) as src,zipfile.ZipFile(p/'download/geminib.zip','w',zipfile.ZIP_DEFLATED) as dst:
 for info in src.infolist():
  before=src.read(info);after=replacements.get(info.filename.split('/')[-1],before)
  assert len(before)==len(after);dst.writestr(info,after)
  manifest.append(dict(name=info.filename,size=len(after),changed=before!=after,sha256=hashlib.sha256(after).hexdigest()))
(p/'analysis/rom-manifest.json').write_text(json.dumps({'title':'Verdant Flight native Z80','code_max':max(b for a,b in used),'files':manifest},indent=2))
print('Native ROM built. Program ends at',hex(max(b for a,b in used)))
